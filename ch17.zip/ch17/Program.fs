﻿open Cards
open Solitaire

newDeck 
  |> shuffle 
  |> Actions.deal 
  |> loopGame Printing.printScreen Actions.updateGame
  |> ignore